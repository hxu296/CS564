var searchData=
[
  ['readheader',['readHeader',['../classbadgerdb_1_1_file.html#af55ceccd74f65de593a6fdfb4c77bb8d',1,'badgerdb::File']]],
  ['readpage',['readPage',['../classbadgerdb_1_1_buf_mgr.html#a9f853f0f1d4628e7e14374d0c7c6a4f3',1,'badgerdb::BufMgr::readPage()'],['../classbadgerdb_1_1_file.html#a00ac0e04c45c5c8d5183212eed870e38',1,'badgerdb::File::readPage()'],['../classbadgerdb_1_1_page_file.html#a704f9a4f927c372bb3546a761f88a532',1,'badgerdb::PageFile::readPage()'],['../classbadgerdb_1_1_blob_file.html#aef77c7b9776493212bad13202bd94f58',1,'badgerdb::BlobFile::readPage()']]],
  ['reason',['reason',['../classbadgerdb_1_1_bad_index_info_exception.html#a445797e655d6086c3e4cf5352eb96916',1,'badgerdb::BadIndexInfoException']]],
  ['reason_5f',['reason_',['../classbadgerdb_1_1_bad_index_info_exception.html#af2faa12c3b71e73b573e8f05f304f2ea',1,'badgerdb::BadIndexInfoException']]],
  ['record_5fid',['record_id',['../classbadgerdb_1_1_invalid_record_exception.html#a7cac504679cb65e114552cf6480e0151',1,'badgerdb::InvalidRecordException']]],
  ['record_5fid_5f',['record_id_',['../classbadgerdb_1_1_invalid_record_exception.html#af1a2e1ad376303aa5411b7d168634586',1,'badgerdb::InvalidRecordException']]],
  ['recordid',['RecordId',['../structbadgerdb_1_1_record_id.html',1,'badgerdb']]],
  ['refbit',['refbit',['../classbadgerdb_1_1_bad_buffer_exception.html#af871746d373d9a16e2203a783e06d00e',1,'badgerdb::BadBufferException']]],
  ['relationname',['relationName',['../structbadgerdb_1_1_index_meta_info.html#acbc581ff8c78929a9dc2dd69eb45c88a',1,'badgerdb::IndexMetaInfo']]],
  ['remove',['remove',['../classbadgerdb_1_1_buf_hash_tbl.html#a5739cc2b22c74d62e25c9d3d316144d8',1,'badgerdb::BufHashTbl::remove()'],['../classbadgerdb_1_1_file.html#a1cc69467366badbd68021ac76a91190e',1,'badgerdb::File::remove()']]],
  ['ridarray',['ridArray',['../structbadgerdb_1_1_leaf_node_int.html#af1502858816ea899eaeaec3371df53a8',1,'badgerdb::LeafNodeInt::ridArray()'],['../structbadgerdb_1_1_leaf_node_double.html#ad68075f70b1e222e853f586ba6717c76',1,'badgerdb::LeafNodeDouble::ridArray()'],['../structbadgerdb_1_1_leaf_node_string.html#ad84243e8bb0dffd14323eb300021d0ff',1,'badgerdb::LeafNodeString::ridArray()']]],
  ['ridkeypair',['RIDKeyPair',['../classbadgerdb_1_1_r_i_d_key_pair.html',1,'badgerdb']]],
  ['rightsibpageno',['rightSibPageNo',['../structbadgerdb_1_1_leaf_node_int.html#aa4a0bbe2b3f3b750ba26d51daae998e1',1,'badgerdb::LeafNodeInt::rightSibPageNo()'],['../structbadgerdb_1_1_leaf_node_double.html#a44886ec83ec1e074dc42653b8824353f',1,'badgerdb::LeafNodeDouble::rightSibPageNo()'],['../structbadgerdb_1_1_leaf_node_string.html#a492ba54f5943f778326c28085fcb0530',1,'badgerdb::LeafNodeString::rightSibPageNo()']]],
  ['rootpageno',['rootPageNo',['../structbadgerdb_1_1_index_meta_info.html#ac79603b5b67018044bccc56818ec363f',1,'badgerdb::IndexMetaInfo']]]
];
