SELECT COUNT(*)
FROM Users
WHERE Users.location = 'New York';
